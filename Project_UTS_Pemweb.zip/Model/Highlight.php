<?php

class Highlight{
    public $id, $id_berita;
    function setData($id, $id_berita){
        $this->id = $id;
        $this->id_berita = $id_berita;
    }
}

?>