<?php

class Kategori{
    public $id, $name;
    function setData($id, $name){
        $this->id = $id;
        $this->name = $name;
    }
}


?>