function redirectLogin(){
    location.href = 'index.php?logindulu=yes';
}