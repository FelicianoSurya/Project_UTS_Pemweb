function detailBerita(id){
    location.href = "DetailNews.php?detail=" + id;
}
function redirectKategori(id){
    location.href = "./News.php?kategori=" + id;
}